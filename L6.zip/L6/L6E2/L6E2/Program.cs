﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6E2
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine(" Digite um termo");
                int t = Convert.ToInt16(Console.ReadLine());

                int[] ramos = new int[t];
                ramos[0] = 1;
                int na = 0;

                for (int i = 0; i < t - 1; i++)
                {
                    if (i != t - 1)
                    {
                        ramos[i + 1] = ramos[i] + na;
                    }

                    na = ramos[i];

                }

                Console.WriteLine("O termo desejado é {0}", ramos[t - 1]);
                Console.ReadKey();
            } 
        }
    }
}
