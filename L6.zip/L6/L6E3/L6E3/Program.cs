﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6E3
{
    class Program
    {
        static void Main(string[] args)
        {

            {
                Console.WriteLine("Digite o numero para recebe-lo em fatorial");
                int f = Convert.ToInt16(Console.ReadLine());

                int[] fat = new int[f];
                int n = 1;
                int result = 1;


                for (int i = 0; i <= (f - 1); i++)
                {
                    if (i == 0)
                    {
                        fat[i] = f;
                    }
                    else
                    {
                        fat[i] = f - n;
                        n++;
                    }
                }



                foreach (var calc in fat)
                {
                    result = result * calc;
                }

                Console.WriteLine("Seu resultado {0}", result);
                Console.ReadKey();
            }
        }

    }
}

